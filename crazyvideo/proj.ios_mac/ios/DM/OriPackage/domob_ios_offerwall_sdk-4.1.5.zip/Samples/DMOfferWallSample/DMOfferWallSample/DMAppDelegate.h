//
//  DMAppDelegate.h
//  DMOfferWallSample
//
//  Copyright (c) 2012年 domob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
