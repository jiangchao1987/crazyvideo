//
//  DODemoConstants.h
//  DomobOfferWallSDK
//
//  Created by Johnny on 13-3-28.
//  Copyright (c) 2013年 domob. All rights reserved.
//

#ifndef DomobOfferWallSDK_DODemoConstants_h
#define DomobOfferWallSDK_DODemoConstants_h
#define PUBLISHER_ID @"96ZJ39xwzegKfwTA/L" // online

#endif
