---------------------------------————————————
  多盟 OfferWall iOS SDK 64位发行包，说明文档
---------------------------------————————————

说明:
   针对苹果的A7处理器开发的静态库libDomobOfferWallSDK_64.a 您如果只想支持iOS7及更高的系统，同时希望支持64位模式，可以尝试将上层目录中的DMOfferWallSDK文件夹下的libDomobOfferWallSDK_64.a 替换,然后将DMOfferWallSDK 文件夹添加到工程。

注意：
   请您在Xcode5.0或者更高版本开发，同时Deployment Target最低设置为iOS7.0