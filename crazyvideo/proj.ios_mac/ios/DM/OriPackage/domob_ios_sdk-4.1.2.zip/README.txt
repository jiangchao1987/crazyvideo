---------------------------------
  多盟 iOS SDK 发行包，说明文档
---------------------------------
注意:

Samples 示例工程 请去gitHub下载，下载地址：

    https://github.com/Domob-SDK/domob-ios-ad-sdk-sample

    为了在运行示例工程时能出广告,请从多盟官网网站（http://www.domob.cn）获取您的Publisher ID。

本SDK包的内容如下: 

DomobAdSDK\
    包含 Domob iOS SDK 库文件、头文件以及相关支持文件

UserGuide.pdf
    Domob iOS SDK 的用户指南文档

README.txt
    本自述文件

最新的更新日志，请访问：http://www.domob.cn/developers/changelog/ios_sdk_changelog.html

